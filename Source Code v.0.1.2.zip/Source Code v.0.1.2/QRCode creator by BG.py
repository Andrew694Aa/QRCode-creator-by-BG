import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import qrcode
import os
from PIL import Image, ImageTk
from io import BytesIO
import json
import time

versionText = "v.0.1.2"
folderPath = "c:/qrcodes"
preview_image_ref = None
settings_file = "settings.json"

def load_settings():
    global folderPath
    try:
        with open(settings_file, "r", encoding="utf-8") as f:
            data = json.load(f)
            folderPath = data.get("folderPath", "c:/qrcodes")
    except:
        folderPath = "c:/qrcodes"

def save_settings():
    data = {"folderPath": folderPath}
    with open(settings_file, "w", encoding="utf-8") as f:
        json.dump(data, f)

def delete_preview():
    global preview_image_ref
    preview_image_ref = None
    preview_label.config(image='')

def update_preview(text):
    delete_preview()
    if not text or text == "Ссылка либо текст...":
        preview_label.config(image='')
        return
    try:
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(text)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        img = img.resize((280, 280), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(img)
        global preview_image_ref
        preview_image_ref = photo
        preview_label.config(image=photo)
    except:
        preview_label.config(image='')

def on_button_click():
    text = entry.get().strip()
    if not text or text == "Ссылка либо текст...":
        messagebox.showerror("Ошибка", "Напишите текст или ссылку!")
        return
    try:
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(text)
        qr.make(fit=True)
        if not os.path.exists(folderPath):
            os.makedirs(folderPath)
        timestamp = int(time.time())
        filename = f"qrcode_{timestamp}.png"
        filepath = os.path.join(folderPath, filename)
        img = qr.make_image(fill_color="black", back_color="white")
        img.save(filepath)
        messagebox.showinfo("Успех", f"QR-код сохранён:\n{filename}")
        os.startfile(folderPath)
        errors.config(text=f"Сохранено: {filename}", foreground="green")
    except Exception as e:
        messagebox.showerror("Ошибка", f"Не удалось сохранить:\n{str(e)}")
        errors.config(text="Ошибка сохранения", foreground="red")

def on_path_button_click():
    global folderPath
    folder_path = filedialog.askdirectory(title="Выберите папку", mustexist=True)
    if folder_path:
        folderPath = folder_path
        save_settings()
        path_label.config(text=f"Путь: {os.path.basename(folderPath)}")
        errors.config(text="Путь обновлён", foreground="green")

def on_clear():
    entry.delete(0, tk.END)
    entry.insert(0, "Ссылка либо текст...")
    entry.config(foreground="grey")
    delete_preview()

def on_about():
    messagebox.showinfo("О программе", f"QRCode creator by BelGen\n\nВерсия: {versionText}")

def on_entry_click(event):
    if entry.get() == "Ссылка либо текст...":
        entry.delete(0, tk.END)
        entry.config(foreground="black")

def on_focus_out(event):
    text = entry.get().strip()
    if not text:
        entry.insert(0, "Ссылка либо текст...")
        entry.config(foreground="grey")

def on_entry_change(event):
    text = entry.get().strip()
    root.after(400, lambda: update_preview(text))

load_settings()

root = tk.Tk()
root.title("QRCode creator by BelGen")
root.geometry("700x600")
root.resizable(False, False)

main_frame = ttk.Frame(root, padding="20")
main_frame.pack(fill=tk.BOTH, expand=True)

left_frame = ttk.Frame(main_frame)
left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))

preview_frame = tk.Frame(left_frame, bg="white", relief="raised", bd=2, width=320, height=380)
preview_frame.pack(fill=tk.BOTH, expand=True)
preview_frame.pack_propagate(False)
preview_frame.pack(pady=(0, 15))

preview_label = tk.Label(preview_frame, text="Предпросмотр QR-кода", bg="white", fg="grey",
                        font=("Helvetica", 12))
preview_label.pack(expand=True)

action_button = ttk.Button(left_frame, text="Создать QRCode", command=on_button_click)
action_button.pack(pady=10, fill=tk.X)

path_frame = ttk.Frame(left_frame)
path_frame.pack(pady=5, fill=tk.X)
path_label = ttk.Label(path_frame, text=f"Путь: {os.path.basename(folderPath)}", font=("Helvetica", 9))
path_label.pack(side=tk.LEFT)
ttk.Button(path_frame, text="Выбрать путь", command=on_path_button_click).pack(side=tk.RIGHT)

clear_button = ttk.Button(left_frame, text="Очистить", command=on_clear)
clear_button.pack(pady=(10,0), fill=tk.X)

separator = ttk.Separator(main_frame, orient=tk.VERTICAL)
separator.pack(side=tk.LEFT, fill=tk.Y, padx=10)

right_frame = ttk.Frame(main_frame)
right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

greeting_label = ttk.Label(right_frame, text="Добро пожаловать", font=("Helvetica", 14))
greeting_label.pack(pady=(0, 5))
greeting_labell = ttk.Label(right_frame, text="в QRCode creator!", font=("Helvetica", 14))
greeting_labell.pack(pady=(0, 20))

entry = tk.Entry(right_frame, width=45, foreground="grey", font=("Helvetica", 12))
entry.pack(pady=(0, 20))
entry.insert(0, "Ссылка либо текст...")
entry.bind("<FocusIn>", on_entry_click)
entry.bind("<FocusOut>", on_focus_out)
entry.bind("<KeyRelease>", on_entry_change)

errors = ttk.Label(right_frame, text="", font=("Helvetica", 10), foreground="red")
errors.pack(pady=(20, 0))

bottom_frame = tk.Frame(root, bg="lightgray")
bottom_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=(0, 5))

about_button = tk.Button(bottom_frame, text="О программе", bg="lightgray", fg="#666",
                         relief="flat", font=("Helvetica", 8), cursor="hand2",
                         command=on_about)
about_button.pack(side=tk.RIGHT, padx=10)

version = tk.Label(bottom_frame, text=f"Версия: {versionText}", bg="lightgray", fg="#666", font=("Helvetica", 8))
version.pack(side=tk.RIGHT, padx=(10, 5))

root.mainloop()
