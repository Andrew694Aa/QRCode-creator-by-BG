import tkinter as tk
from tkinter import ttk, messagebox
import qrcode
import os
from PIL import Image, ImageTk
from io import BytesIO

versionText = "v.0.1.1"

preview_image_ref = None

def delete_preview():
    global preview_image_ref
    preview_image_ref = None
    preview_label.config(image='')

def update_preview(text):
    delete_preview()
    if not text or text == "Ссылка либо текст...":
        preview_label.config(image='')
        return
    try:
        qr = qrcode.make(text)
        bio = BytesIO()
        qr.save(bio, format='PNG')
        bio.seek(0)
        img = Image.open(bio)
        img = img.resize((250, 250), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(img)
        global preview_image_ref
        preview_image_ref = photo
        preview_label.config(image=photo)
    except Exception:
        preview_label.config(image='')

def on_button_click():
    text = entry.get().strip()
    if text == "" or text == "Ссылка либо текст...":
        errors.config(text="Напишите текст или ссылку!", foreground="red")
        return
    errors.config(text="")
    try:
        qr = qrcode.make(text)
        save_dir = "c:/qrcodes"
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        filepath = os.path.join(save_dir, "qrcode.png")
        qr.save(filepath)
        errors.config(text=f"QR-код сохранён в {filepath}", foreground="green")
        os.startfile(save_dir)
    except Exception as e:
        errors.config(text=f"Ошибка: {e}", foreground="red")

def on_about():
    messagebox.showinfo("О программе", f"QRCode creator by BelGen\n{versionText}")

def on_entry_click(event):
    if entry.get() == "Ссылка либо текст...":
        entry.delete(0, tk.END)
        entry.config(foreground="black")

def on_focus_out(event):
    text = entry.get().strip()
    entry.config(foreground="grey")
    if text == "":
        entry.insert(0, "Ссылка либо текст...")

def on_entry_change(event):
    text = entry.get().strip()
    root.after(300, lambda: update_preview(text))

root = tk.Tk()
root.title("QRCode creator by BelGen")
root.geometry("600x500")
root.resizable(False, False)

main_frame = ttk.Frame(root, padding="20")
main_frame.pack(fill=tk.BOTH, expand=True)

left_frame = ttk.Frame(main_frame)
left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))

preview_frame = tk.Frame(left_frame, bg="white", relief="raised", bd=2, width=300, height=350)
preview_frame.pack(fill=tk.BOTH, expand=True)
preview_frame.pack_propagate(False)

preview_label = tk.Label(preview_frame, text="Предпросмотр QR-кода", bg="white", fg="grey", font=("Helvetica", 12))
preview_label.pack(expand=True, pady=20)

action_button = ttk.Button(left_frame, text="Создать QRCode", command=on_button_click)
action_button.pack(pady=10)

separator = ttk.Separator(main_frame, orient=tk.VERTICAL)
separator.pack(side=tk.LEFT, fill=tk.Y, padx=10)

right_frame = ttk.Frame(main_frame)
right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

greeting_label = ttk.Label(right_frame, text="Добро пожаловать", font=("Helvetica", 14))
greeting_labell = ttk.Label(right_frame, text=" в QRCode creator!", font=("Helvetica", 14))
greeting_label.pack(pady=(0, 20))
greeting_labell.pack(pady=(0, 20))

entry = tk.Entry(right_frame, width=40, foreground="grey", font=("Helvetica", 11))
entry.pack(pady=(0, 20))
entry.insert(0, "Ссылка либо текст...")
entry.bind("<FocusIn>", on_entry_click)
entry.bind("<FocusOut>", on_focus_out)
entry.bind("<KeyRelease>", on_entry_change)

errors = ttk.Label(right_frame, text="", font=("Helvetica", 9), foreground="red")
errors.pack(pady=(20, 0))

bottom_frame = tk.Frame(root, bg="lightgray")
bottom_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=(0, 5))

version = tk.Label(bottom_frame, text=versionText, bg="lightgray", fg="#666", font=("Helvetica", 8))
version.pack(side=tk.RIGHT, padx=(10, 5))

about_button = tk.Button(bottom_frame, text="О программе", bg="lightgray", fg="#666",
                         relief="flat", font=("Helvetica", 8), cursor="hand2",
                         command=on_about)
about_button.pack(side=tk.RIGHT)

root.mainloop()
