import tkinter as tk
from tkinter import ttk
import qrcode
import os

versionText = "v.0.1.0"

def on_button_click():
    text = entry.get().strip()

    if text == "" or text == "Ссылка либо текст...":
        errors.config(text="Напишите текст или ссылку!", foreground="red")
        return

    errors.config(text="")

    try:
        qr = qrcode.make(text)

        save_dir = "c:/qrcodes"
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)

        filepath = os.path.join(save_dir, "qrcode.png")
        qr.save(filepath)

        errors.config(text=f"QR-код сохранён в {filepath}", foreground="green")
        os.startfile(save_dir)  # Открываем папку

    except Exception as e:
        errors.config(text=f"Ошибка: {e}", foreground="red")


def on_entry_click(event):
    if entry.get() == "Ссылка либо текст...":
        entry.delete(0, tk.END)
        entry.config(foreground="black")


def on_focus_out(event):
    if entry.get() == "":
        entry.insert(0, "Ссылка либо текст...")
        entry.config(foreground="grey")


root = tk.Tk()
root.title("QRCode creator by BelGen")
root.geometry("400x250")
root.resizable(False, False)

greeting_label = ttk.Label(root, text="Добро пожаловать в QRCode creator!", font=("Helvetica", 12))
greeting_label.pack(pady=20)

version = ttk.Label(root, text= versionText, font=("Helvetica", 8))
version.pack(pady=20)

entry = tk.Entry(root, width=30, foreground="grey")
entry.pack(pady=10)
entry.insert(0, "Ссылка либо текст...")
entry.bind("<FocusIn>", on_entry_click)
entry.bind("<FocusOut>", on_focus_out)

action_button = ttk.Button(root, text="Создать QRCode", command=on_button_click)
action_button.pack(pady=10)

errors = ttk.Label(root, text="", font=("Helvetica", 8))
errors.pack(pady=10)

root.mainloop()